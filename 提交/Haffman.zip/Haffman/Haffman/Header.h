﻿#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stack>
