﻿#pragma once

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>