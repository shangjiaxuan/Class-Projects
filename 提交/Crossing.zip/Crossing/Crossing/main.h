﻿#pragma once

#include "Colors.h"

void name_ver();
void prompt();
void function();
void Exit();
