﻿#pragma once

#include <iostream>
#include <stdexcept>
