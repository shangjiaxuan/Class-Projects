﻿#pragma once

extern int number;				//路口数量

extern int valid;				//允许的两两组合数
