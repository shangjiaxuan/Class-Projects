﻿#include "UI.h"

using namespace std;

UI This;

int main(int argc, char* argv[]) {
	This.UI_main();
	return 0;
}

