#include "Index.h"

Index::Index() {

}


Index::~Index() {

}
